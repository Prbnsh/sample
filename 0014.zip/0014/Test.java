import java.util.*;
import javax.swing.JOptionPane;


class Customer {
    String userName;
    int pinNumber;

    Customer(String userName, int pinNumber) {
        this.userName = userName;
        this.pinNumber = pinNumber;
    }
}

class CustomerManager {

    ArrayList<Customer> customer = new ArrayList<>();

    void addCustomer(String userName, int pinNumber) {
        customer.add(new Customer(userName, pinNumber));
        System.out.println("successfull");
    }

    void removeCustomer(String userName, int pinNumber) {
        customer.remove(new Customer(userName, pinNumber));
    }

    void displayCustomers() {
        for (Customer x : customer) {
            System.out.println(x);
        }
    }
}

// super class(Account)
class Account {

    final double minBalance = 1000;

    double currentBalance = minBalance;

    public Account(int currentBalance) {
        this.currentBalance = currentBalance;
    }

    double getBalance() {
        return 0;
    }

    void withdraw(int amount) {
        // code
    }

    void deposite(int amount) {
        // code
    }
}

// sub class(SavingAccount)
class SavingAccount extends Account {

    public SavingAccount(int currentBalance) {
        super(currentBalance);
    }

    double getBalance() {
        return currentBalance;
    }

    void withdraw(int amount) {
        if (currentBalance <= minBalance) {
            System.out.println("You cannot withdraw. Minimum balance requirement not met.");
        } else if (amount <= 0) {
            System.out.println("Invalid withdrawal amount. Please enter a positive amount.");
        } else if (amount > (currentBalance - minBalance)) {
            System.out.println("Insufficient funds. You can only withdraw up to: " + (currentBalance - minBalance));
        } else {
            currentBalance -= amount;
            System.out.println("You successfully withdrew " + amount + ". Your current balance is " + currentBalance);
        }
    }

    void deposite(int amount) {
        if (amount > 200000) {
            System.out.println("you can not deposite more than 200000 try again");
        } else {
            currentBalance += amount;
            System.out.println("You successfully deposite " + amount + ". Your current balance is " + currentBalance);
        }
    }
}

// sub class(FixdepositAccout)
class FixdepositAccout extends Account {

    public FixdepositAccout(int currentBalance) {
        super(currentBalance);
        // this accout is not create yet
    }

}

public class Test {
    public static void main(String[] args) {

        // Create Scanner object
        Scanner sc = new Scanner(System.in);

        // Create object manage customer class
        CustomerManager mngcustomer = new CustomerManager();

        // Create Account class object(obj1)
        Account obj1 = new SavingAccount(1000);

        // Maximum inputs and valid_inputs
        int maxinputs = 3;
        int userInvalidInput = 0;

        // Give the user 3 chances
        for (int attempt = 1; attempt <= maxinputs; attempt++) {
            // Call the user manual method
            displayMenu();
            // Get the user input
            String userInput = sc.next();
            // user Selection
            switch (userInput) {
                case "1":
                    // Check Balance method call here
                    System.out.print("your current balance is :" + obj1.getBalance());
                    break;
                case "2":
                    System.out.print("enter your withdraw ammount :");
                    int widthammout = sc.nextInt();
                    obj1.withdraw(widthammout);
                    break;
                case "3":
                    System.out.print("enter your deposite ammount :");
                    int depammout = sc.nextInt();
                    obj1.deposite(depammout);
                    // displayMenu();
                    break;
                case "4":
                    System.out.print("Enter your username :");
                    String username = sc.next();
                    System.out.print("Enter your pin :");
                    int pin = sc.nextInt();
                    mngcustomer.addCustomer(username, pin);
                    break;
                case "5":
                    mngcustomer.displayCustomers();
                    break;
                case "6":
                    System.out.println("Thank you for joining us. Please come again!");
                    System.exit(0);
                    break;
                default:
                    userInvalidInput++;
                    if (userInvalidInput < maxinputs) {
                        System.out.println();
                        JOptionPane.showMessageDialog(null,"Error: Invalid input. Please try again. Yor left automaticaly after "
                                + (maxinputs - userInvalidInput) + "  attempts");
                    } else {
                        JOptionPane.showMessageDialog(null,"Too many invalid attempts. Exiting program.");
                        System.exit(0);
                    }
                    break;
            }
        }

        // Close the Scanner
        sc.close();
    }

    // Create user manual
    static void displayMenu() {
        System.out.println();
        System.out.println("WELCOME TO THE  ABC BANK:\n");
        System.out.println("--******************************--\n");
        System.out.println("--** Check balance    --> 1\n");
        System.out.println("--** Withdraw balance --> 2\n");
        System.out.println("--** Deposit balance  --> 3\n");
        System.out.println("--** Register here    --> 4\n");
        // System.out.println("--** Display --> 5\n");
        System.out.println("--** Exit             --> 6\n");
        System.out.println("--******************************--");
        System.out.print("Choose your option: ");
    }
}